$(document).ready(function(){
	document.write('<h1>您的浏览器版本过低，建议您使用IE10+、chrome等先进的浏览器，以获得最佳体验</h1>');
});